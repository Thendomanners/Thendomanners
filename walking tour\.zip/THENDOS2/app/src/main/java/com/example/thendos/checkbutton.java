//this is a class for selection of italy

package com.example.thendos;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.RadioGroup;

public class checkbutton extends AppCompatActivity {
 //this is to declare all the variables
     EditText name,email;
    TextView txtemail,txtname;
    Button submitionbtn;
    RadioGroup radiobuttonday, radiobuttontime;
    TextView daytxt,timetxt;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkbutton);

       /* radiobuttonday = findViewById(R.id.radioGroup);
        radiobuttontime = findViewById(R.id.radioGroup2);

        daytxt = findViewById(R.id.textday);
        timetxt = findViewById(R.id.radioGroup2);*/

        //for assigning each element to requirred edit text
        name = (EditText) findViewById(R.id.editText);
        email = (EditText) findViewById(R.id.editText2);
//for assigning id to a button
        txtemail = findViewById(R.id.textView);
        txtname = findViewById(R.id.textView6);
        submitionbtn = findViewById(R.id.button3);
        final Intent mainscreen = new Intent(this,MainActivity.class);
//for submisson button
        submitionbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"details successfully saved and submited..",Toast.LENGTH_SHORT).show();
                startActivity(mainscreen);
            }
        });
    }
}