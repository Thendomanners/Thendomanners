// this is to control all the activity because it is the main

package com.example.thendos;

 // import all the components needed for the program to work

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    //this is to declared the buttons

 private Button button1;
    private Button button2;
    private Button button3;
    private Button button ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//assiging of a button to a class below for each of the button
        button1 = findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {opencity();}
        });

        button2 = findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {opencity2();}
        });

        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {opencity3();}
        });

         button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {opencheckbutton();}
        });
    }
    // below are classes to open city
    public void opencity(){
        Intent intent = new Intent(this ,city.class);
        startActivity(intent);}
    // below are classes to open city 2 class
    public void opencity2(){
        Intent intent = new Intent(this ,city.class);
        startActivity(intent);}
    // below are classes to open city class
    public void opencity3(){
        Intent intent = new Intent(this ,city3.class);
        startActivity(intent);}
    // below are classes to open checkbutton
    public void opencheckbutton(){
        Intent intent = new Intent(this ,checkbutton.class);
        startActivity(intent);}

}
