package com.example.thendos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class city2 extends AppCompatActivity {
    private Button button4 ;
    private Button button5 ;
    private Button button6 ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city2);
        button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {opencheckbutton();}
        });

        button5 = findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {opencheckmarseille();}
        });
        button6 = findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v)
            {openchecklyon();}
        });



    }


    public void opencheckbutton(){
        Intent intent = new Intent(this ,roma.class);
        startActivity(intent);}

    public void opencheckmarseille(){
        Intent intent = new Intent(this ,venive.class);
        startActivity(intent);}
    public void openchecklyon(){
        Intent intent = new Intent(this ,pisa.class);
        startActivity(intent);}

}
