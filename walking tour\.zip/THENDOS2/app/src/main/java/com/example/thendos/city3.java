//this is a class for selection of england

package com.example.thendos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class city3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city3);
    }
}
